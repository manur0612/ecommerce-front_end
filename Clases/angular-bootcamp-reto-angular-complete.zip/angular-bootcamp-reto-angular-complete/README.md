# Reto final

1. Crear un component llamado login (html,css,ts) tip: usar find
2. En https://mockapi.io/ crear un endpoint de users
   /api/dmc/users
   - id
   - name
   - profile_pic
   - role
3. Crear angular service llamado services/user-service
4. Si se logea bien se redirecciona al HomeComponent